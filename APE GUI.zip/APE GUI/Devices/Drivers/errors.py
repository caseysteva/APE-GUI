# -*- coding: utf-8 -*-
"""
Created on Fri Jun 16 10:49:26 2017

@author: Alexander Cook
"""

def print_error(error_text, stop_on_error = False):
    print(error_text)
    
def print_message(message):
    print(message)